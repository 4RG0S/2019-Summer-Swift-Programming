//
//  ViewController.m
//  practice1
//
//  Created by cse on 2018. 7. 19..
//  Copyright © 2018년 cse. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *label_text_helloworld;
@property (weak, nonatomic) IBOutlet UITextField *InputMessage;

@end
int8_t a=0;
@implementation ViewController
- (IBAction)button_change:(UIButton*)sender {
    NSLog(@"%@", sender.titleLabel);
//    if (a==0) {
//        a=1;
//        self.label_text_helloworld.text=@"Hey~";
//
 //    }else{
//        a=0;
//        self.label_text_helloworld.text=@"Why~";
//    }
//    self.label_text_helloworld.text = self.InputMessage.text;
    [self.label_text_helloworld setText:self.InputMessage.text ];
}

-(void)viewWillAppear:(BOOL)animated{
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.label_text_helloworld.text= @"Hi";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
