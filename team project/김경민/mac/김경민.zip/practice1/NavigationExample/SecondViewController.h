//
//  SecondViewController.h
//  NavigationExample
//
//  Created by cse on 2018. 7. 26..
//  Copyright © 2018년 cse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
@property (nonatomic,strong) NSString * message;
@end
